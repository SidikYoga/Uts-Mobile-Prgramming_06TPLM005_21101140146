import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';


void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'UTS SIDIK YOGA PRATAMA',
      home: MyHomePage(),
    );
  }
}

class MyHomePage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Shoes'),
        actions: [
          Padding(
            padding: EdgeInsets.only(right: 9.0),
            child: CircleAvatar(
              radius: 30.0,
              backgroundImage: AssetImage('assets/fotop.png'),
            ),
          ),
        ],
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            // Container 1
            Container(
              width: 350,
              height: 115,
              margin: EdgeInsets.only(bottom: 12),
              color: Color.fromARGB(255, 243, 105, 255),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Padding(
                    padding: EdgeInsets.all(10),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Text(
                          'Nike SB Zoom Blazer',
                          style: TextStyle(
                            fontSize: 18,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        Text(
                          'Mid Premium',
                          style: TextStyle(
                            fontSize: 18,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        SizedBox(height: 20),
                        Text(
                          'USD 8,795',
                          style: TextStyle(
                            fontSize: 10,
                            color: Colors.grey[800],
                          ),
                        ),
                      ],
                    ),
                  ),
                  Image.asset(
                    'assets/nikesb.png',
                    width: 150,
                    height: 120,
                    fit: BoxFit.cover,
                  ),
                ],
              ),
            ),

            // Container 2
            Container(
              width: 350,
              height: 115,
              margin: EdgeInsets.only(bottom: 10),
              color: Color.fromARGB(255, 143, 255, 246),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Padding(
                    padding: EdgeInsets.all(10),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Text(
                          'Nike Air Zoom Pegasus ',
                          style: TextStyle(
                            fontSize: 18,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        Text(
                          'Men`s Rood Running Shoes ',
                          style: TextStyle(

                            fontSize: 12,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        SizedBox(height: 20),
                        Text(
                          'USD 9,995',
                          style: TextStyle(
                            fontSize: 10,
                            color: Colors.grey[800],
                          ),
                        ),
                      ],
                    ),
                  ),
                  Image.asset(
                    'assets/nikepegasuss.png',
                    width: 130,
                    height: 150,
                    fit: BoxFit.cover,
                  ),
                ],
              ),
            ),

            // Container 3
            Container(
              width: 350,
              height: 115,
              margin: EdgeInsets.only(bottom: 10),
              color: Color.fromARGB(255, 255, 196, 231),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Padding(
                    padding: EdgeInsets.all(10),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Text(
                          'Nike ZoomX Vaporfly ',
                          style: TextStyle(
                            fontSize: 18,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        Text(
                          'Men`s Rood Racing Shoes ',
                          style: TextStyle(
                            fontSize: 12,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        SizedBox(height: 20),
                        Text(
                          'USD 19,695',
                          style: TextStyle(
                            fontSize: 10,
                            color: Colors.grey[800],
                          ),
                        ),
                      ],
                    ),
                  ),
                  Image.asset(
                    'assets/nikevaporflyy.png',
                    width: 140,
                    height: 150,
                    fit: BoxFit.cover,
                  ),
                ],
              ),
            ),
            // Container 4
            Container(
              width: 350,
              height: 115,
              margin: EdgeInsets.only(bottom: 10),
              color: const Color.fromARGB(255, 216, 216, 216),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Padding(
                    padding: EdgeInsets.all(10),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Text(
                          'Nike Air Force 1 S50',
                          style: TextStyle(
                            fontSize: 18,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        Text(
                          'Older Kids` Shoe',
                          style: TextStyle(
                            fontSize: 12,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        SizedBox(height: 22),
                        Text(
                          '1 Colour',
                          style: TextStyle(
                            fontSize: 10,
                            color: Colors.grey[800],
                          ),
                        ),
                        Text(
                          'USD 6,295',
                          style: TextStyle(
                            fontSize: 10,
                            color: Colors.grey[800],
                          ),
                        ),
                      ],
                    ),
                  ),
                  Image.asset(
                    'assets/nikeforcee.png',
                    width: 150,
                    height: 130,
                    fit: BoxFit.cover,
                  ),
                ],
              ),
            ),
            // Container 5
            Container(
              width: 350,
              height: 115,
              margin: EdgeInsets.only(bottom: 10),
              color: Color.fromARGB(255, 255, 244, 141),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Padding(
                    padding: EdgeInsets.all(10),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Text(
                          'Nike Waffle One ',
                          style: TextStyle(
                            fontSize: 18,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        Text(
                          'Men`s Shoes ',
                          style: TextStyle(
                            fontSize: 10,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        SizedBox(height: 20),
                        Text(
                          'USD 8,295',
                          style: TextStyle(
                            fontSize: 16,
                            color: Colors.grey[800],
                          ),
                        ),
                      ],
                    ),
                  ),
                  Image.asset(
                    'assets/nikewafflee.png',
                    width: 150,
                    height: 120,
                    fit: BoxFit.cover,
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
